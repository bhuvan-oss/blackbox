


#include <xc.h>
#include "matrix_keypad.h"
#include "clcd.h"
#include "ds1307.h"
#include "ext_eeprom.h"

extern char time[9], speed, O_f, lap, flag;
static char temp_f = 0;
static int delay = 0, delay1 = 0;
char hr, min, sec, time_f = 0, key, prekey;

void set_time(void) 
{
    clcd_print("HH:MM:SS", LINE1(0));
    if (!temp_f) 
    {
        hr = (time[0] - 48) * 10 + time[1] - 48;             ///allocating the index with hr:sec:mi
        min = (time[3] - 48) * 10 + time[4] - 48;
        sec = (time[6] - 48) * 10 + time[7] - 48;
        temp_f = 1;
    }
    if (delay1++ < 500)
    {
        clcd_putch(hr / 10 + 48, LINE2(0)); //10's position
        clcd_putch(hr % 10 + 48, LINE2(1)); //1's position
        clcd_putch(':', LINE2(2));
        clcd_putch(min / 10 + 48, LINE2(3));
        clcd_putch(min % 10 + 48, LINE2(4));
        clcd_putch(':', LINE2(5));
        clcd_putch(sec / 10 + 48, LINE2(6));
        clcd_putch(sec % 10 + 48, LINE2(7));
    } 
    else if(delay1 < 1000)
    {
        if (time_f == 2) {
            clcd_print("  ", LINE2(0));             ///spacing for shift the field
        } else if (time_f == 1) {
            clcd_print("  ", LINE2(3));
        } 
        else
            clcd_print("  ", LINE2(6));
    }
    else
        delay1 = 0;

    key = read_switches(LEVEL_CHANGE);
    if (key != 0xFF) 
    {
        prekey = key;
        if (delay++ == 2000) 
        {
            if (key == MK_SW5) 
            {
                write_ds1307(0, ((sec / 10) *10 | sec % 10));
                write_ds1307(1, ((min / 10) << 4 | min % 10));
                write_ds1307(2, ((hr / 10) << 4 | hr % 10));
                char arr[5];
                arr[0] = (time[0] - 48) * 10 + time[1] - 48;   //hr
                arr[1] = (time[3] - 48) * 10 + time[4] - 48;   //min
                arr[2] = (time[6] - 48) * 10 + time[7] - 48;   //sec
//                arr[3] = 10;
//                arr[4] = speed;
                for (int i = 0; i < 5; i++)
                write_ext_eeprom(lap * 5 + i, arr[i]);
                lap++;
                if (lap == 10)
                {
                    lap = 0;
                    O_f = 1;
                }
                CLEAR_DISP_SCREEN;
                 temp_f = 0;
                flag = 2;
            } 
            else if (key == MK_SW6) 
            {
                CLEAR_DISP_SCREEN;
                 temp_f = 0;
                flag = 2;
            }

        }
    }
    else if (delay < 2000 && delay > 0) 
    {
        delay = 0;
        if (prekey == 5) 
        {
            //short press logic of 5 key
            if (time_f == 0) 
            {
                if (sec < 59)
                    sec++;
                else
                    sec = 0;

            }
            else if (time_f == 1)
            {
                if(min<60)
                min++;
               // min %= 60;
                else
                    min=0;
            } 
            else if (time_f == 2)
            {
                if(hr<24)
                hr++;
                //hr %= 24;
                else
                    hr=0;
            }
        } 
        else if (prekey == 6) 
        {
            //logic of 6 key short press
            time_f++;
            time_f %= 3;
        }
    }
}
