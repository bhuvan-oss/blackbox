



#include <xc.h>
#include "eeprom.h"
#include "clcd.h"
#include "matrix_keypad.h"
#include "main1.h"
#include "ext_eeprom.h"


char i = 0, newpasswd1 = 0, newpasswd2 = 0;
unsigned int delay = 0;
extern char flag;

void change_password(char key) 
{
    if (i < 4) 
    {
        if (i == 0) 
        {
            CLEAR_DISP_SCREEN;
        }
      
        clcd_print("Enter passwd", LINE1(0));
      
        if (delay++ < 1000) 
        {
            clcd_putch('_', LINE2(i));
        } 
        else if (delay++ < 2000) 
        {
            clcd_putch(' ', LINE2(i));
        } 
        else
            delay = 0;


        if (key == MK_SW5) 
        {
            clcd_putch('*', LINE2(i));
            newpasswd1 = newpasswd1 << 1;
            i++;
        } else if (key == MK_SW6) {
            clcd_putch('*', LINE2(i));
            newpasswd1 = newpasswd1 << 1 | 1;
            i++;

        }
        if (i == 4)
            CLEAR_DISP_SCREEN;
    } 
    else if (i < 8) 
    {
        clcd_print("Re-Enter passwd", LINE1(0));
        if (delay++ < 1000) 
        {
            clcd_putch('_', LINE2(i - 4));
        } 
        else if (delay++ < 2000) 
        {
            clcd_putch(' ', LINE2(i - 4));
        } 
        else
            delay = 0;

        if (key == MK_SW5) 
        {
            clcd_putch('*', LINE2(i - 4));
            newpasswd2 = newpasswd2 << 1;
            i++;
        } 
        else if (key == MK_SW6) 
        {
            clcd_putch('*', LINE2(i - 4));
            newpasswd2 = newpasswd2 << 1 | 1;
            i++;
        }
    } else {
        if (newpasswd1 == newpasswd2) 
        {
            clcd_print("change passwd      ", LINE1(0));
            clcd_print("SUCCESSFULLY       ", LINE2(0));
            if (delay++ == 1000) 
            {
                delay = 0;
                write_ext_eeprom(200, newpasswd1);
                CLEAR_DISP_SCREEN;
                flag = 2;
            }
        }
        else 
        {
            clcd_print("     FAILURE ", LINE2(0));
            if (delay++ == 1000) {
                delay = 0;
                flag = 2;
            }

        }



    }
}


