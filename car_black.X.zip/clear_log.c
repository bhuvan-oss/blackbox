


#include <xc.h>
#include "main1.h"
#include "clcd.h"
#include "ext_eeprom.h"

extern char lap, O_f, time[9], speed, flag;
static int delay = 0;

void clear_log() {

    clcd_print("   CLEAR LOG      ", LINE1(0));
    clcd_print("   SUCCESSFULL   ", LINE2(0));
    if (delay++ == 1000) {

        delay = 0;
        lap = 0, O_f = 0;
        char arr[5];
        arr[0] = (time[0] - 48) * 10 + time[1] - 48;
        arr[1] = (time[3] - 48) * 10 + time[4] - 48;
        arr[2] = (time[6] - 48) * 10 + time[7] - 48;
        arr[3] = 9;
        arr[4] = speed;
        for (int i = 0; i < 5; i++)
            write_ext_eeprom(lap * 5 + i, arr[i]);
        lap++;
        flag = 2;

    }
}

