


#include <xc.h>
#include "main1.h"
#include "clcd.h"
#include "matrix_keypad.h"
#include "ext_eeprom.h"

void viewlog();
extern char O_f, lap, prekey, ET[][3], flag;   //lap=address
char start_index, a_index = 0;

void viewlog(void) {
    clcd_print("#  TIME    E  SP", LINE1(0));
    if (O_f == 0)
        start_index = 0;
    else
        start_index = lap;
    char key = read_switches(0);
    static int time_m = 0;
    if (key != 255) //checking if any switch is pressed
    {
        time_m++;
        prekey = key;
        if (time_m == 1000) 
        {
            time_m = 0;
            if (prekey == 6) 
            {
                CLEAR_DISP_SCREEN;
                flag = 2;
            }
        }
    } else if (time_m < 1000 && time_m > 0) {
        time_m = 0;
        if (prekey == 5) 
        {
            if (a_index > 0)
                a_index--;
        }
        else if (prekey == 6) 
        {
            if (O_f == 0) 
            {
                if (a_index < lap - 1)
                    a_index++;
            } 
            else 
            {
                if (a_index < 9)
                    a_index++;
            }
        }

    }

    char temp = read_ext_eeprom((start_index + a_index) % 10 * 5);
    clcd_putch(48 + a_index, LINE2(0));
    clcd_putch(' ', LINE2(1));
    clcd_putch(48 + temp / 10, LINE2(2));
    clcd_putch(48 + temp % 10, LINE2(3));
    clcd_putch(':', LINE2(4));
    temp = read_ext_eeprom((start_index + a_index) % 10 * 5 + 1);
    clcd_putch(48 + temp / 10, LINE2(5));
    clcd_putch(48 + temp % 10, LINE2(6));
    clcd_putch(':', LINE2(7));
    temp = read_ext_eeprom((start_index + a_index) % 10 * 5 + 2);
    clcd_putch(48 + temp / 10, LINE2(8));
    clcd_putch(48 + temp % 10, LINE2(9));
    clcd_putch(' ', LINE2(10));
    temp = read_ext_eeprom((start_index + a_index) % 10 * 5 + 3);
    clcd_print(ET[temp], LINE2(11));
    clcd_putch(' ', LINE2(13));
    temp = read_ext_eeprom((start_index + a_index) % 10 * 5 + 4);
    clcd_putch(48 + temp / 10, LINE2(14));
    clcd_putch(48 + temp % 10, LINE2(15));

}
