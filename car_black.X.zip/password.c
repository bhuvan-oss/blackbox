
#include "clcd.h"
#include "matrix_keypad.h"
#include <xc.h>
#include "timer0.h"
#include "main1.h"


unsigned char U_pass = 0, bit_count = 0, attempt_count = 5;
extern unsigned char O_pass, flag, sec;
unsigned int delay = 0, delay1 = 0, delay2 = 0;

void password(char key) 
{
    if (bit_count <= 3) 
    {
        clcd_print("ENTER PASSWORD", LINE1(0));

        if (delay++ == 6000) {
            delay = 0;
            flag = 0;
        }
        if (delay1++ < 1000) {
            clcd_putch('_', LINE2(bit_count));
        }
        else if (delay1 < 2000)
            clcd_putch(' ', LINE2(bit_count));
        else
            delay1 = 0;
        if (key == 5) {
            delay = 0;
            clcd_putch('*', LINE2(bit_count));
            U_pass = 0 | (U_pass << 1);
            bit_count++;
        }
        else if (key == 6) {
            delay = 0;
            clcd_putch('*', LINE2(bit_count));
            U_pass = 1 | (U_pass << 1);
            bit_count++;
        }
    }
    if (bit_count == 4) 
    {
        if ((O_pass & 0x0F) == (U_pass & 0x0F)) 
        {
            clcd_print("SUCCESS: PASSWD", LINE2(0));
            if (delay2++ == 1000) {
                bit_count = 0;
                delay2 = 0;
                CLEAR_DISP_SCREEN;
                flag = 2;
                delay = 0;
            }
        }
        else {
            if (attempt_count > 1) 
            {
                clcd_putch('0' + attempt_count - 1, LINE2(0));
                clcd_print(" Attempts left", LINE2(1));
                if (delay++ == 2000) 
                {
                    delay = 0;
                    bit_count = 0;
                    attempt_count--;
                    clcd_print("                  ", LINE2(0));
                }
            }
            else 
            {
                GIE = PEIE = TMR0IE = 1;
                clcd_print("You are blocked    ", LINE1(0));
                clcd_print("wait ... ", LINE2(0));
                clcd_putch(sec / 100 + 48, LINE2(9));
                clcd_putch(sec / 10 % 10 + 48, LINE2(10));
                clcd_putch(sec % 10 + 48, LINE2(11));
                clcd_print(" sec ", LINE2(12));
                if (sec == 0) 
                {
                    GIE = PEIE = TMR0IE = 0;
                    attempt_count = 5;
                    bit_count = 0;
                    CLEAR_DISP_SCREEN;
                    clcd_print(" ENTER PASSWORD  ", LINE1(0));
                }

            }


        }
    }
}
