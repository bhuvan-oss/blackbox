


#include <xc.h>
#include "main1.h"
#include "clcd.h"
#include "uart.h"
#include "ext_eeprom.h"

static int delay = 0;
extern char O_f, lap, ET[][3], time[5], speed, flag;
char i, start_index;

void putch(unsigned char byte) {
    /* Output one byte */
    /* Set when register is empty */
    while (!TXIF) {
        continue;
    }
    TXREG = byte;
}

int puts(const char *s) {
    while (*s) {
        putch(*s++);
    }
    return 0;
}

void downloadlog() {

    init_uart();
    clcd_print("Download-log    ", LINE1(0));
    clcd_print("Successful", LINE2(0));


    if (delay++ == 1000) {
        char arr[5];
        arr[0] = (time[0] - 48) * 10 + time[1] - 48;
        arr[1] = (time[3] - 48) * 10 + time[4] - 48;
        arr[2] = (time[6] - 48) * 10 + time[7] - 48;
        arr[3] = 8;
        arr[4] = speed;
        for (int i = 0; i < 5; i++)
            write_ext_eeprom(lap * 5 + i, arr[i]);
        lap++;
        if (lap == 10) {
            lap = 0;
            O_f = 1;
        }
        if (O_f == 0) {
            i = lap;
            start_index = 0;
        } else {
            i = 10;
            start_index = lap;
        }




        puts("S.no\tTime\tEvent\tSpeed");
        for (char a_index = 0; a_index < i; a_index++) {
            putch('\n');
            putch('\r');
            char temp = read_ext_eeprom((start_index + a_index) % 10 * 5);
            putch(48 + a_index);
            putch(' ');
            putch(48 + temp / 10);
            putch(48 + temp % 10);
            putch(':');
            temp = read_ext_eeprom((start_index + a_index) % 10 * 5 + 1);
            putch(48 + temp / 10);
            putch(48 + temp % 10);
            putch(':');
            temp = read_ext_eeprom((start_index + a_index) % 10 * 5 + 2);
            putch(48 + temp / 10);
            putch(48 + temp % 10);
            putch(' ');
            temp = read_ext_eeprom((start_index + a_index) % 10 * 5 + 3);
            puts(ET[temp]);
            putch(' ');
            temp = read_ext_eeprom((start_index + a_index) % 10 * 5 + 4);
            putch(48 + temp / 10);
            putch(48 + temp % 10);
            delay = 0;
            CLEAR_DISP_SCREEN;
            flag = 2;
        }
    }
}
