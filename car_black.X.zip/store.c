


#include <xc.h>
#include "ext_eeprom.h"
extern unsigned char time[9], speed, event;
char O_f = 0;
char lap = 0;

void store(void) 
{
    char arr[5];
    arr[0] = (time[0] - 48) * 10 + time[1] - 48;
    arr[1] = (time[3] - 48) * 10 + time[4] - 48;
    arr[2] = (time[6] - 48) * 10 + time[7] - 48;
    arr[3] = event;
    arr[4] = speed;
    for (int i = 0; i < 5; i++)
    write_ext_eeprom(lap * 5 + i, arr[i]);
    lap++;
    if (lap == 10) 
    {
        lap = 0;
        O_f = 1;
    }
}
