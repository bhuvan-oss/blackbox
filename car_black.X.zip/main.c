/*
 * NAME :BHUVAN UMESH
 * DISCRIPTION:CAR BLACK BOX
 * FILE NAME:main.c
 */




#include <xc.h>
#include "clcd.h"
#include "matrix_keypad.h"
#include "adc.h"
#include "ext_eeprom.h"
#include "timer0.h"
#include "uart.h"
#include "main1.h"
#include "i2c.h"
#include "eeprom.h"
#include "ds1307.h"

unsigned char clock_reg[3];
char time[9];
char key, event = 0, speed, flag = 0;
char ET[][3] = {"ON", "GR", "GN", "G1", "G2", "G3", "G4", "C "};
unsigned char O_pass = 0x5;
char s_flag = 0, m_index = 0, prekey, m_flag;
unsigned short time_m = 0;
char menu[5][17] = {"view log       ", "Download log      ", "Clear log      ", "Set time     ", "Change passwd     "};

static void init_config(void) //function definition of init_config
{
    init_clcd(); //function call for init_Plcd
    init_matrix_keypad();
    init_adc();
    T0CS = 0;
    TMR0 = 6;
    TMR0IF = 1;
    init_i2c();
    init_ds1307();
    O_pass = 0x0A;
    //write_internal_eeprom(200, O_pass);


}
static void get_time(void)
{
	clock_reg[0] = read_ds1307(HOUR_ADDR);
	clock_reg[1] = read_ds1307(MIN_ADDR);
	clock_reg[2] = read_ds1307(SEC_ADDR);

	if (clock_reg[0] & 0x40)
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	else
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	time[2] = ':';
	time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
	time[4] = '0' + (clock_reg[1] & 0x0F);
	time[5] = ':';
	time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
	time[7] = '0' + (clock_reg[2] & 0x0F);
	time[8] = '\0';
}

void init_uart(void) {
    /* Serial initialization */
    RX_PIN = 1;
    TX_PIN = 0;

    /* TXSTA:- Transmitor Status and control Register */
    /* 9bit TX enable or disable bit */
    TX9 = 0;
    /* UART Tarsmition enable bit */
    TXEN = 1;
    /* Synchronous or Asynchronous mode selection */
    /* Asynchronous */
    SYNC = 0;
    /* Send the Break character bit */
    SENDB = 0;
    /* Low or High baud rate selection bit */
    /* High Baud Rate */
    BRGH = 1;

    /* RCSTA :- Recepition Status and control Register */
    /* TX/RC7 and RX/RC6 act as serial port */
    SPEN = 1;
    /* 9bit RX enable or disable bit */
    RX9 = 0;
    /* Continous reception enable or disable */
    CREN = 1;

    /* BAUDCTL:- Baud rate control register */
    /* Auto baud detection overflow bit */
    ABDOVF = 0;
    /* 16bit baud generate bit */
    BRG16 = 0;
    /* Wakeup enable bit */
    WUE = 0;
    /* Auto baud detect enable bit */
    ABDEN = 0;

    /* Baud Rate Setting Register */
    /* Set to 10 for 115200, 64 for 19200 and 129 for 9600 */
    SPBRG = 129;


    /* TX interrupt enable bit */
    TXIE = 1;
    /* TX interrupt flag bit */
    TXIF = 0;
    /* RX interrupt enable bit */
    RCIE = 1;
    /* RX interrupt enable bit */
    RCIF = 0;
}

void main(void) {
    init_config(); //calling the init-config
    get_time();

    clcd_print(" Time     GN  SP", LINE1(0)); //continuously printing the char at position 0 in line1
    clcd_print(ET[event], LINE2(10));
    
    store();



    while (1) //super loop
    {
        get_time();
        key = read_switches(STATE_CHANGE);
        if (key == MK_SW1)//sw1
        {
            event = 7;
            store();
        }
        else if (key == MK_SW2) {

            if (event == 7) {
                store();
                event = 2;
            } else if (event < 6) {
                ++event;
                store();
            }
        } else if (key == MK_SW3)//sw3
        {

            if (event == 7) {
                store();
                event = 2;
            } else if (event > 1) {
                --event;
                store();
            }
        }
        //clcd_putch(event + 48, LINE1(10));
        if (flag == 0) 
        {
            clcd_print(" Time     E   SP", LINE1(0)); //continuously printing the char at position 0 in line1
            clcd_print(ET[event], LINE2(10));
            speed = read_adc(CHANNEL4) / 10.33;
            clcd_print(time, LINE2(0)); //continuously printing the string(abcd) at position 4 to 7 in line2
            clcd_putch(speed / 10 + 48, LINE2(14));
            clcd_putch(speed % 10 + 48, LINE2(15));
            if (key == 5) {
                flag = 1;
                CLEAR_DISP_SCREEN;
            }
        } 
        else if (flag == 1) 
        {
            O_pass = read_ext_eeprom(200);
            password(key);
        }
        else if (flag == 2) 
        {
            if (s_flag == 0) 
            {
                clcd_print("->", LINE1(0));
                clcd_print("  ", LINE2(0));
            } 
            else {
                clcd_print("  ", LINE1(0));
                clcd_print("->", LINE2(0));
            }
            clcd_print(menu[m_index], LINE1(2));
            clcd_print(menu[m_index + 1], LINE2(2));
            key = read_switches(0);
            if (key != 255) //checking if any switch is pressed
            {
                time_m++;
                prekey = key;
                if (time_m == 1000) {
                    time_m = 0;
                    if (prekey == 5) {
                        m_flag = s_flag + m_index;
                        flag = 3;
                        CLEAR_DISP_SCREEN;
                    }
                    else if (prekey == 6) {
                        CLEAR_DISP_SCREEN;
                        flag = 0;
                    }
                }
            } 
            else if (time_m < 1000 && time_m > 0) {
                time_m = 0;
                if (prekey == 5) 
                {
                    if (s_flag == 1)
                        s_flag = 0;
                    else if (m_index > 0)
                        m_index--;
                }
                else if (prekey == 6) 
                {
                    if (s_flag == 0)
                        s_flag = 1;
                    else if (m_index < 3)
                        m_index++;
                }

            }




        } else if (flag == 3) {
            if (m_flag == 0)
                viewlog();
            else if (m_flag == 1)
                downloadlog();
            else if (m_flag == 2)
                clear_log();
            else if (m_flag == 3)
                set_time();

            else if (m_flag == 4)
                change_password(key);

        }
    }
}