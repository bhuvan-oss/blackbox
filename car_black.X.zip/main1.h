

void downloadlog();
void viewlog();
void clear_log();
void store();
void password(char key);
void change_password(char key);
void set_time(void);